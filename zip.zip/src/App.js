import './App.css';
// import Client from './components/Client';
// import Installer from './components/Installer';
import Mainform from './components/Mainform';
import './index.css';

function App() {
  return (
    <div className="App">
      {/* <Client/>
      <Installer/> */}
      <Mainform/>
    </div>
  );
}

export default App;
